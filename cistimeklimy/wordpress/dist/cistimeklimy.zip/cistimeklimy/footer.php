<?php
/**
 * Pás nad pätičkou + pätička. (Generované z ../index.html skriptom build_theme.py)
 * Text pásu sa dá zmeniť: get_footer( null, array( 'title' => '…', 'text' => '…' ) ).
 */
defined( 'ABSPATH' ) || exit;
$ck_band = wp_parse_args( isset( $args ) && is_array( $args ) ? $args : array(), array(
  'title' => 'Zlepšite kvalitu vzduchu ešte dnes',
  'text'  => 'Objednajte si profesionálne čistenie klimatizácie a dýchajte zdravší vzduch.',
) );
?>
<!-- PÁS NAD PÄTIČKOU -->
<section class="cta-band">
  <div class="wrap">
    <div class="band rv">
      <div>
        <h2><?php echo esc_html( $ck_band['title'] ); ?></h2>
        <p><?php echo esc_html( $ck_band['text'] ); ?></p>
      </div>
      <div class="actions">
        <a class="btn" href="<?php echo esc_attr( ck_tel() ); ?>"><span><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1l-2.3 2.2Z"/></svg><?php echo esc_html( ck_phone() ); ?></span></a>
        <a class="btn white" href="<?php echo esc_url( ck_home_anchor( 'kontakt' ) ); ?>"><span>Objednať online</span></a>
      </div>
    </div>
  </div>
</section>

</main>
<footer class="site-footer">
  <div class="wrap">
    <div class="foot-grid">
      <div class="foot-brand">
        <img src="<?php echo esc_url( CK_ASSETS ); ?>/logo/cistimeklimy-logo-white.svg" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="200" height="36">
        <p>Profesionálne čistenie klimatizácií a radiátorov v Bratislave a okolí. Zdravší vzduch pre váš domov aj kanceláriu.</p>
        <div class="social">
          <?php if ( ck_opt( 'facebook' ) ) : ?><a href="<?php echo esc_url( ck_opt( 'facebook' ) ); ?>" aria-label="Facebook" rel="noopener"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 8h3V4h-3a4 4 0 0 0-4 4v2H7v4h3v8h4v-8h3l1-4h-4V8z"/></svg></a>
          <?php endif; if ( ck_opt( 'instagram' ) ) : ?><a href="<?php echo esc_url( ck_opt( 'instagram' ) ); ?>" aria-label="Instagram" rel="noopener"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".8" fill="currentColor"/></svg></a><?php endif; ?>
        </div>
      </div>
      <div>
        <h4>Služby</h4>
        <ul>
          <li><a href="<?php echo esc_url( ck_home_anchor( 'sluzby' ) ); ?>">Nástenné klimatizácie</a></li>
          <li><a href="<?php echo esc_url( ck_home_anchor( 'sluzby' ) ); ?>">Kazetové a kanálové</a></li>
          <li><a href="<?php echo esc_url( ck_home_anchor( 'sluzby' ) ); ?>">Dezinfekcia</a></li>
          <li><a href="<?php echo esc_url( ck_radiatory_url() ); ?>">Čistenie radiátorov</a></li>
        </ul>
      </div>
      <div>
        <h4>Odkazy</h4>
        <ul>
          <li><a href="<?php echo esc_url( ck_home_anchor( 'postup' ) ); ?>">Ako prebieha čistenie</a></li>
          <li><a href="<?php echo esc_url( ck_home_anchor( 'referencie' ) ); ?>">Referencie</a></li>
          <li><a href="<?php echo esc_url( ck_home_anchor( 'kontakt' ) ); ?>">Kde pôsobíme</a></li>
          <li><a href="<?php echo esc_url( ck_privacy_url() ); ?>">Ochrana osobných údajov</a></li>
        </ul>
      </div>
      <div>
        <h4>Kontakt</h4>
        <ul>
          <li><a href="<?php echo esc_attr( ck_tel() ); ?>"><?php echo esc_html( ck_phone() ); ?></a></li>
          <li><a href="mailto:<?php echo esc_attr( antispambot( ck_email() ) ); ?>"><?php echo esc_html( antispambot( ck_email() ) ); ?></a></li>
          <li><?php echo esc_html( ck_opt( 'area' ) ); ?></li>
          <li><?php echo esc_html( ck_opt( 'hours' ) ); ?></li>
        </ul>
      </div>
    </div>
    <div class="foot-bottom">
      <span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
      <span>Čistý vzduch v každom ročnom období</span>
    </div>
  </div>
</footer>

<div class="callbar">
  <a class="btn" href="<?php echo esc_attr( ck_tel() ); ?>"><span>Zavolať</span></a>
  <a class="btn ink" href="<?php echo esc_url( ck_home_anchor( 'kontakt' ) ); ?>"><span>Objednať</span></a>
</div>

<?php wp_footer(); ?>
</body>
</html>
