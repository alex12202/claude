<?php
/**
 * Hlavička webu. (Generované z ../index.html skriptom build_theme.py)
 */
defined( 'ABSPATH' ) || exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#main">Preskočiť na obsah</a>
<header class="site-header">
  <nav class="nav wrap" aria-label="Hlavná navigácia">
    <a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( CK_ASSETS ); ?>/logo/cistimeklimy-logo.svg" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="230" height="42"></a>
    <?php
    wp_nav_menu( array(
      'theme_location' => 'primary',
      'container'      => false,
      'depth'          => 1,
      'fallback_cb'    => 'ck_menu_fallback',
    ) );
    ?>
    <a class="btn ink" href="<?php echo esc_attr( ck_tel() ); ?>"><span><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1l-2.3 2.2Z"/></svg><?php echo esc_html( ck_phone() ); ?></span></a>
    <button class="menu-toggle" type="button" aria-label="Menu" aria-expanded="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h10"/></svg></button>
  </nav>
</header>

<main id="main">
