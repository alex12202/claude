<?php
/**
 * Bežná stránka (napr. Ochrana osobných údajov).
 */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post();
	?>
<section class="page-hero">
  <div class="wrap">
    <p class="crumbs"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Úvod</a> / <?php the_title(); ?></p>
    <h1><?php the_title(); ?></h1>
  </div>
</section>
<section class="page-simple">
  <div class="wrap">
    <article class="prose"><?php the_content(); ?></article>
  </div>
</section>
	<?php
endwhile;
get_footer();
