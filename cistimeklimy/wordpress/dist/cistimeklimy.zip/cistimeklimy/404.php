<?php
/**
 * Stránka nenájdená.
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<section class="page-hero">
  <div class="wrap">
    <span class="tagline">Chyba 404</span>
    <h1 style="margin-top:16px">Táto stránka <em>neexistuje</em></h1>
    <p class="lead" style="margin-top:16px">Možno bola presunutá. Pokračujte na úvod alebo nám rovno zavolajte.</p>
    <div class="hero-actions" style="margin-top:24px">
      <a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span>Na úvodnú stránku</span></a>
      <a class="btn ghost" href="<?php echo esc_attr( ck_tel() ); ?>"><span><?php echo esc_html( ck_phone() ); ?></span></a>
    </div>
  </div>
</section>
<?php
get_footer();
