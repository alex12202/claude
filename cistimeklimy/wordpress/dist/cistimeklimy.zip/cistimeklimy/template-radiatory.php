<?php
/**
 * Template Name: Radiátory
 *
 * Podstránka o čistení radiátorov. Text článku sa upravuje v editore stránky.
 * (Generované z ../radiatory.html skriptom build_theme.py)
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>

<section class="page-hero">
  <div class="wrap page-hero-grid">
    <div>
      <p class="crumbs"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Úvod</a> / Čistenie radiátorov</p>
      <span class="tagline">Nová služba</span>
      <h1 style="margin-top:18px">Zaprášený radiátor <em>hreje horšie</em> a víri prach po byte</h1>
      <p class="lead" style="margin-top:20px">Medzi lamelami vykurovacích telies sa roky usádza prach, srsť a peľ. Keď sa radiátor zohreje, teplý vzduch ich vynáša do miestnosti. Vyčistíme ich zvnútra, nielen zvonka.</p>
      <div class="hero-actions" style="margin-top:28px">
        <a class="btn" href="<?php echo esc_url( ck_home_anchor( 'kontakt' ) ); ?>"><span>Objednať čistenie radiátorov</span></a>
        <a class="btn ghost" href="<?php echo esc_attr( ck_tel() ); ?>"><span><?php echo esc_html( ck_phone() ); ?></span></a>
      </div>
    </div>
    <svg class="radiator-art rv d2" viewBox="0 0 320 300" role="img" aria-label="Ilustrácia radiátora s prachom a teplým vzduchom">
      <g fill="none" stroke="#ec7b2e" stroke-width="4" stroke-linecap="round" opacity=".85">
        <path d="M70 70c-10-14 10-22 0-36"><animate attributeName="opacity" values=".2;1;.2" dur="3s" repeatCount="indefinite"/></path>
        <path d="M130 64c-10-14 10-22 0-36"><animate attributeName="opacity" values="1;.2;1" dur="3s" repeatCount="indefinite"/></path>
        <path d="M190 70c-10-14 10-22 0-36"><animate attributeName="opacity" values=".2;1;.2" dur="3.4s" repeatCount="indefinite"/></path>
        <path d="M250 64c-10-14 10-22 0-36"><animate attributeName="opacity" values="1;.2;1" dur="3.4s" repeatCount="indefinite"/></path>
      </g>
      <g fill="#fff" stroke="#0e2c4a" stroke-width="4">
        <rect x="40" y="90" width="44" height="170" rx="12"/>
        <rect x="98" y="90" width="44" height="170" rx="12"/>
        <rect x="156" y="90" width="44" height="170" rx="12"/>
        <rect x="214" y="90" width="44" height="170" rx="12"/>
      </g>
      <path d="M26 118h264M26 232h264" stroke="#0e2c4a" stroke-width="6" stroke-linecap="round"/>
      <g fill="#8a8f96" opacity=".75">
        <circle cx="62" cy="160" r="3"/><circle cx="70" cy="190" r="2"/><circle cx="55" cy="210" r="2.5"/>
        <circle cx="120" cy="150" r="2.5"/><circle cx="112" cy="200" r="3"/><circle cx="128" cy="222" r="2"/>
        <circle cx="178" cy="170" r="3"/><circle cx="186" cy="140" r="2"/><circle cx="170" cy="215" r="2.5"/>
        <circle cx="236" cy="160" r="2"/><circle cx="244" cy="200" r="3"/><circle cx="228" cy="222" r="2.5"/>
      </g>
      <rect x="20" y="276" width="280" height="6" rx="3" fill="#4b96d1"/>
    </svg>
  </div>
</section>

<section>
  <div class="wrap article-grid">
    <article class="prose">
      <?php while ( have_posts() ) : the_post(); the_content(); endwhile; ?>
    </article>

    <aside class="aside-card rv d2">
      <span class="tagline light">Objednávka</span>
      <h3>Vyčistíme radiátory aj klimatizáciu naraz</h3>
      <p>Zavolajte alebo nechajte číslo, ozveme sa do 60 minút.</p>
      <a class="phone" href="<?php echo esc_attr( ck_tel() ); ?>"><?php echo esc_html( ck_phone() ); ?></a>
      <a class="btn white" href="<?php echo esc_url( ck_home_anchor( 'kontakt' ) ); ?>"><span>Objednať online</span></a>
    </aside>
  </div>
</section>

<?php get_footer( null, array(
  'title' => 'Vyčistíme radiátory pred sezónou',
  'text'  => 'Radiátory aj klimatizáciu vyčistíme pri jednej návšteve.',
) ); ?>
