<?php
/**
 * Úvodná stránka. (Generované z ../index.html skriptom build_theme.py)
 * Kontakty a slider: Vzhľad → Prispôsobiť → Čistímeklimy.
 */
defined( 'ABSPATH' ) || exit;
get_header();
$ck_slides = ck_slides();
?>

<!-- HERO: slider cez celú sekciu -->
<section class="hero" data-slider aria-roledescription="slider" aria-label="Ukážky našej práce">
  <div class="hero-slides">
<?php foreach ( $ck_slides as $ck_i => $ck_slide ) : ?>
    <figure class="slide" data-caption="<?php echo esc_attr( $ck_slide['caption'] ); ?>" data-title="<?php echo esc_attr( $ck_slide['title'] ); ?>" style="--focus: <?php echo esc_attr( $ck_slide['focus'] ); ?>"><img src="<?php echo esc_url( $ck_slide['src'] ); ?>"<?php if ( $ck_slide['srcset'] ) : ?> srcset="<?php echo esc_attr( $ck_slide['srcset'] ); ?>" sizes="100vw"<?php endif; ?> alt="<?php echo esc_attr( $ck_slide['alt'] ); ?>"<?php echo 0 === $ck_i ? ' fetchpriority="high"' : ' loading="lazy"'; ?>></figure>
    <?php endforeach; ?>
  </div>
  <canvas class="hero-air" aria-hidden="true"></canvas>
  <div class="louvers" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
  <div class="wrap hero-grid">
    <div class="hero-copy">
      <span class="tagline">Čistý vzduch v každom ročnom období</span>
      <h1 class="hero-title"><?php echo ck_kses_title( $ck_slides[0]['title'] ); ?></h1>
      <p class="lead">Rozoberieme jednotku, vyčistíme výmenník aj ventilátor a vydezinfikujeme ju. Pracujeme v Bratislave a okolí, na objednávku prídeme do 60 minút.</p>
      <div class="hero-actions">
        <a class="btn" href="#kontakt"><span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>Objednať čistenie</span></a>
        <a class="btn ghost" href="<?php echo esc_attr( ck_tel() ); ?>"><span><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1l-2.3 2.2Z"/></svg><?php echo esc_html( ck_phone() ); ?></span></a>
      </div>
      <ul class="hero-facts">
        <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Zásah do 60 minút</li>
        <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg>Záruka kvality</li>
        <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/></svg>Faktúra aj pre firmy</li>
      </ul>
    </div>
    <div class="hero-side">
      <div class="badge-999" aria-label="Odstránime až 99,9 % baktérií a plesní">
        <b>99,9<small>%</small></b>
        <span>baktérií<br>a plesní preč</span>
      </div>
      <div>
        <p class="slide-caption" aria-live="polite"></p>
        <div class="slider-dots"></div>
      </div>
    </div>
  </div>
</section>

<!-- PÁS VÝHOD -->
<div class="perks">
  <ul class="wrap">
    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 9.5c1.5 1 4.5 1 6 0M9 14c1.5-1 4.5-1 6 0"/></svg><span><b>Bez plesní a baktérií</b>Zdravší vzduch doma</span></li>
    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 1.5M9 2h6"/></svg><span><b>Rýchly zásah</b>U vás do 60 minút</span></li>
    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg><span><b>Bratislava a okolie</b>Prídeme k vám domov</span></li>
    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="9" r="6"/><path d="M8.5 13.5L7 22l5-3 5 3-1.5-8.5"/><path d="M9.5 9l1.8 1.8 3.2-3.3"/></svg><span><b>Skúsení odborníci</b>Všetky značky klimatizácií</span></li>
  </ul>
</div>

<!-- PREČO ČISTIŤ – POROVNANIE PRED/PO -->
<section class="why" id="preco">
  <div class="wrap why-grid">
    <div>
      <div class="compare rv-img">
        <img src="<?php echo esc_url( CK_ASSETS ); ?>/img/coil-dirty.webp" alt="Výmenník pred čistením">
        <img class="after" src="<?php echo esc_url( CK_ASSETS ); ?>/img/coil-clean.webp" alt="Výmenník po čistení">
        <span class="tag before">Pred čistením</span>
        <span class="tag after-tag">Po čistení</span>
        <div class="handle" aria-hidden="true"></div>
        <input type="range" id="compare-range" min="0" max="100" value="50" aria-label="Posuňte a porovnajte pred a po čistení">
      </div>
      <p class="compare-hint">Potiahnite posúvač doľava a doprava.</p>
    </div>
    <div>
      <div class="sec-head rv">
        <span class="tagline">Prečo čistiť</span>
        <h2>Čo je vo výmenníku, <em>to dýchate</em></h2>
      </div>
      <p class="lead rv d1">V klimatizácii sa časom usádza prach, plesne a baktérie. Pri každom zapnutí ich jednotka rozfúka po miestnosti. Zanesená klimatizácia navyše chladí horšie a míňa viac elektriny.</p>
      <ul class="checklist rv d1">
        <li>Riziko alergií, astmy a problémov s dýchaním</li>
        <li>Nepríjemný zápach a šírenie baktérií</li>
        <li>Vyššia spotreba energie a slabší výkon</li>
        <li>Vyššie riziko porúch a drahých opráv</li>
      </ul>
      <p class="note-yearly rv d2">Odporúčame čistenie minimálne <span>1× ročne</span>.</p>
    </div>
  </div>
</section>

<!-- NESTAČÍ VYČISTIŤ LEN FILTRE -->
<section class="filters">
  <div class="wrap filters-grid">
    <div>
      <div class="sec-head rv">
        <span class="tagline">Hĺbkové čistenie</span>
        <h2>Nestačí vyčistiť <em>len filtre</em></h2>
      </div>
      <p class="lead rv d1">Filtre zachytia iba časť nečistôt. Vo výmenníku, ventilátore a odtoku kondenzátu sa postupne usádzajú baktérie, plesne a biofilm. Bežné čistenie filtrov ich neodstráni.</p>
      <div class="warn rv d2"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/></svg>Práve odtiaľ sa pri každom zapnutí šíria do vzduchu.</div>
    </div>
    <div class="vs rv">
      <figure>
        <div class="cap-top">Filter<br>vidíte ho</div>
        <img src="<?php echo esc_url( CK_ASSETS ); ?>/img/filter.webp" alt="Zanesený filter klimatizácie">
        <figcaption>Zachytí prach zo vzduchu. Opláchnuť ho zvládnete aj sami.</figcaption>
      </figure>
      <span class="vs-mark" aria-hidden="true">+</span>
      <figure>
        <div class="cap-top">Ventilátor<br>skrytý vo vnútri</div>
        <img src="<?php echo esc_url( CK_ASSETS ); ?>/img/rotor.webp" alt="Zanesený rotor ventilátora">
        <figcaption>Bez rozobratia sa k nemu nedostanete. Tu sa hromadia baktérie, plesne a biofilm.</figcaption>
      </figure>
    </div>
  </div>
</section>

<!-- SLUŽBY -->
<section class="services" id="sluzby">
  <div class="wrap">
    <div class="sec-head rv">
      <span class="tagline">Služby</span>
      <h2>Čo všetko <em>čistíme</em></h2>
    </div>
    <div class="svc-grid">
      <article class="svc rv d1">
        <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><rect x="6" y="18" width="46" height="18" rx="4"/><path d="M12 30h34M14 42l-2 6M29 42v7M44 42l2 6"/><path d="M56 12v8M52 16h8" stroke-linecap="round"/></svg>
        <h3>Nástenné klimatizácie</h3>
        <p>Rozobratie, čistenie výmenníka, ventilátora a vaničky, dezinfekcia.</p>
        <a href="#kontakt">Objednať</a>
      </article>
      <article class="svc rv d2">
        <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><path d="M8 26l24-12 24 12-24 12z"/><path d="M8 26v8l24 12 24-12v-8"/><path d="M20 26l12-6 12 6-12 6z"/></svg>
        <h3>Kazetové a kanálové</h3>
        <p>Stropné kazety a potrubné rozvody v kanceláriách a prevádzkach.</p>
        <a href="#kontakt">Objednať</a>
      </article>
      <article class="svc rv d3">
        <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="30" cy="34" r="12"/><path d="M30 16v6M30 46v6M12 34h6M42 34h6M17 21l4 4M39 43l4 4M17 47l4-4M39 25l4-4"/><circle cx="26" cy="31" r="2"/><circle cx="34" cy="37" r="2"/><path d="M50 8v6M47 11h6"/></svg>
        <h3>Dezinfekcia</h3>
        <p>Antibakteriálne ošetrenie, ktoré odstráni až 99,9 % baktérií a plesní.</p>
        <a href="#kontakt">Objednať</a>
      </article>
      <article class="svc rv d4 new">
        <span class="pill">Nové</span>
        <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><rect x="8" y="14" width="8" height="36" rx="3"/><rect x="20" y="14" width="8" height="36" rx="3"/><rect x="32" y="14" width="8" height="36" rx="3"/><rect x="44" y="14" width="8" height="36" rx="3"/><path d="M4 20h56M4 44h56"/></svg>
        <h3>Čistenie radiátorov</h3>
        <p>Zaprášené vykurovacie telesá hrejú horšie a pália prach. Vyčistíme ich zvnútra.</p>
        <a href="<?php echo esc_url( ck_radiatory_url() ); ?>">Zistiť viac</a>
      </article>
    </div>
  </div>
</section>

<!-- AKO PREBIEHA ČISTENIE -->
<section id="postup">
  <div class="wrap">
    <div class="sec-head center rv">
      <span class="tagline">Postup</span>
      <h2>Ako prebieha <em>čistenie klimatizácie</em></h2>
      <p class="lead">Jedna nástenná jednotka zaberie približne hodinu. Pracujeme s ochrannou plachtou, takže u vás po nás nezostane neporiadok.</p>
    </div>
    <ol class="steps" data-steps>
      <li class="rv d1"><span class="step-ico" aria-hidden="true"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="20" cy="20" r="12"/><path d="M29 29l11 11"/><path d="M15 18c1.5-3 4-4 6-4"/></svg></span><h3>Kontrola</h3><p>Skontrolujeme stav klimatizácie a mieru znečistenia.</p></li>
      <li class="rv d2"><span class="step-ico" aria-hidden="true"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="9" width="38" height="15" rx="3"/><path d="M10 19h28"/><path d="M14 30l-3 8M24 30v9M34 30l3 8"/></svg></span><h3>Rozobratie a čistenie</h3><p>Rozoberieme jednotku a odstránime prach, nečistoty a plesne.</p></li>
      <li class="rv d3"><span class="step-ico" aria-hidden="true"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M18 16h10v6l4 5v15a2 2 0 0 1-2 2H16a2 2 0 0 1-2-2V27l4-5z"/><path d="M20 16v-6h8l4 3M20 10h-4"/><path d="M36 8l3-2M37 13h4M36 18l3 2"/><path d="M19 33h8M23 29v8"/></svg></span><h3>Dezinfekcia</h3><p>Vydezinfikujeme všetky časti a odstránime baktérie aj zápach.</p></li>
      <li class="rv d4"><span class="step-ico" aria-hidden="true"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M8 30a16 16 0 1 1 32 0"/><path d="M24 30l8-9"/><circle cx="24" cy="30" r="2.5" fill="currentColor"/><path d="M14 40l5 4 11-10" /></svg></span><h3>Kontrola a test</h3><p>Zložíme jednotku a overíme funkčnosť a výkon.</p></li>
    </ol>
    <div class="visible-diff">
      <figure class="rv-img d1" data-par><img src="<?php echo esc_url( CK_ASSETS ); ?>/img/unit-dirty.webp" alt="Jednotka pred čistením"><figcaption>PRED</figcaption></figure>
      <figure class="rv-img d2" data-par><img src="<?php echo esc_url( CK_ASSETS ); ?>/img/unit-clean.webp" alt="Jednotka po čistení"><figcaption>PO</figcaption></figure>
      <div class="diff-note rv d3"><b>Rozdiel, ktorý je vidieť.</b><p>A cítiť. Zápach zmizne hneď po prvom zapnutí.</p></div>
    </div>
  </div>
</section>

<!-- KEDY / AKO ČASTO -->
<section class="when">
  <div class="wrap when-grid">
    <div class="panel panel-when rv">
      <div>
        <h2>Kedy je čas <em>na čistenie?</em></h2>
        <ul class="signs">
          <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 12c1.3-2 2.7-2 4 0s2.7 2 4 0"/></svg>Nepríjemný zápach po zapnutí</li>
          <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v10M8 13l4 4 4-4"/></svg>Slabší výkon chladenia</li>
          <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M13 6l-4 7h4l-2 5"/></svg>Vyššia spotreba elektriny</li>
          <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M9 10h.01M15 10h.01M8.5 15.5c2-1.5 5-1.5 7 0"/></svg>Alergické reakcie počas používania</li>
          <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 10v4M12 8v8M16 10v4"/></svg>Hlučnejšia prevádzka</li>
          <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Od posledného čistenia uplynul viac ako rok</li>
        </ul>
      </div>
      <img src="<?php echo esc_url( CK_ASSETS ); ?>/img/bact.webp" alt="Baktérie v klimatizácii – ilustrácia">
    </div>
    <div class="panel panel-often rv d2">
      <h2>Ako často <em>čistiť?</em></h2>
      <div class="freq"><b>1×</b><span>ročne minimálne</span></div>
      <hr>
      <p>Ak klimatizáciu používate často, máte doma alergika, deti alebo domáce zvieratá, odporúčame čistenie každých <strong>6 až 12 mesiacov</strong>.</p>
      <a class="btn" href="#kontakt"><span>Objednať termín</span></a>
    </div>
  </div>
</section>

<!-- REFERENCIE -->
<section class="refs on-dark" id="referencie">
  <div class="wrap">
    <div class="sec-head rv">
      <span class="tagline light">Referencie</span>
      <h2>Čo hovoria <em>naši zákazníci</em></h2>
    </div>
    <div class="refs-grid">
      <figure class="review rv d1">
        <div class="stars" aria-label="5 z 5">★★★★★</div>
        <blockquote>Profesionálny prístup, rýchly termín a perfektne odvedená práca. Klimatizácia ako nová.</blockquote>
        <footer><span class="ava">MK</span><span><b>Martin K.</b>Bratislava – Ružinov</span></footer>
      </figure>
      <figure class="review rv d2">
        <div class="stars" aria-label="5 z 5">★★★★★</div>
        <blockquote>Konečne čistý vzduch bez zápachu. Odporúčam každému, kto chce dýchať zdravo.</blockquote>
        <footer><span class="ava">ZT</span><span><b>Zuzana T.</b>Petržalka</span></footer>
      </figure>
      <figure class="review rv d3">
        <div class="stars" aria-label="5 z 5">★★★★★</div>
        <blockquote>Pán prišiel načas, všetko vysvetlil a ukázal, čo bolo vo ventilátore. Super skúsenosť.</blockquote>
        <footer><span class="ava">PR</span><span><b>Peter R.</b>Dúbravka</span></footer>
      </figure>
      <div class="refs-photo rv-img" data-par>
        <img src="<?php echo esc_url( CK_ASSETS ); ?>/img/family.webp" alt="Spokojná rodina pod vyčistenou klimatizáciou">
        <span>Čistý vzduch pre celú rodinu</span>
      </div>
    </div>
    <div class="refs-bar rv"><span class="stars">★★★★★</span> Ohodnoťte nás aj vy na Google</div>
  </div>
</section>

<!-- MAPA + OBJEDNÁVKA -->
<section id="kontakt">
  <div class="wrap area-grid">
    <div>
      <div class="sec-head rv">
        <span class="tagline">Kde pôsobíme</span>
        <h2>Bratislava <em>a okolie</em></h2>
      </div>
      <p class="lead rv d1">Prídeme k vám do 60 minút od objednania.</p>
      <ul class="towns rv d1">
        <li>Bratislava</li><li>Senec</li>
        <li>Pezinok</li><li>Modra</li>
        <li>Malacky</li><li>Stupava</li>
        <li>Šamorín</li><li>Ivanka p. D.</li>
      </ul>
    </div>

    <div class="map rv-img">
      <svg viewBox="0 0 700 700" role="img" aria-label="Mapa oblasti: Bratislava, Malacky, Stupava, Pezinok, Modra, Senec, Šamorín">
        <defs>
          <radialGradient id="reach" cx="307" cy="483" r="380" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#4b96d1" stop-opacity=".38"/>
            <stop offset=".75" stop-color="#4b96d1" stop-opacity=".12"/>
            <stop offset="1" stop-color="#4b96d1" stop-opacity="0"/>
          </radialGradient>
          <pattern id="grid" width="35" height="35" patternUnits="userSpaceOnUse"><path d="M35 0H0V35" fill="none" stroke="#d3e3f2" stroke-width="1"/></pattern>
        </defs>
        <rect width="700" height="700" fill="#eef5fb"/>
        <rect width="700" height="700" fill="url(#grid)"/>
        <!-- Malé Karpaty -->
        <path d="M360 385 C390 340 420 300 450 250 S540 110 580 40" fill="none" stroke="#cfe0d4" stroke-width="46" stroke-linecap="round" opacity=".8"/>
        <text x="505" y="130" font-family="Manrope, sans-serif" font-size="15" font-style="italic" fill="#6f8f78" transform="rotate(-52 505 130)">Malé Karpaty</text>
        <!-- Morava a Dunaj -->
        <path d="M130 0 C150 120 175 250 160 360 C150 420 145 450 150 470" fill="none" stroke="#9cc6ea" stroke-width="7" stroke-linecap="round"/>
        <path d="M0 470 C80 465 150 470 220 492 C290 515 330 530 390 565 C450 600 500 650 560 700" fill="none" stroke="#7fb6e3" stroke-width="16" stroke-linecap="round"/>
        <text x="410" y="610" font-family="Manrope, sans-serif" font-size="15" font-style="italic" fill="#3f79a8" transform="rotate(38 410 610)">Dunaj</text>
        <text x="24" y="300" font-family="Manrope, sans-serif" font-size="14" fill="#8aa0b6" letter-spacing="3">RAKÚSKO</text>
        <!-- dosah -->
        <circle cx="307" cy="483" r="380" fill="url(#reach)"/>
        <circle cx="307" cy="483" r="160" fill="none" stroke="#ec7b2e" stroke-width="2.5" stroke-dasharray="8 8" opacity=".8"/>
        <!-- mestá -->
        <g font-family="Manrope, sans-serif" font-weight="700" font-size="17" fill="#0e2c4a">
          <circle cx="220" cy="51" r="6" fill="#0e2c4a"/><text x="232" y="57">Malacky</text>
          <circle cx="230" cy="294" r="6" fill="#0e2c4a"/><text x="242" y="300">Stupava</text>
          <circle cx="510" cy="202" r="6" fill="#0e2c4a"/><text x="522" y="208">Modra</text>
          <circle cx="470" cy="271" r="6" fill="#0e2c4a"/><text x="482" y="277">Pezinok</text>
          <circle cx="600" cy="375" r="6" fill="#0e2c4a"/><text x="588" y="358">Senec</text>
          <circle cx="460" cy="426" r="6" fill="#0e2c4a"/><text x="472" y="432">Ivanka p. D.</text>
          <circle cx="510" cy="660" r="6" fill="#0e2c4a"/><text x="522" y="666">Šamorín</text>
        </g>
        <!-- statický špendlík: Bratislava -->
        <ellipse cx="307" cy="485" rx="16" ry="5" fill="#0c0d0d" opacity=".18"/>
        <path d="M307 485c-6-12-24-26-24-44a24 24 0 0 1 48 0c0 18-18 32-24 44z" fill="#ec7b2e" stroke="#fff" stroke-width="4"/>
        <circle cx="307" cy="440" r="9" fill="#fff"/>
        <text x="280" y="452" text-anchor="end" font-family="'Cistime Display', sans-serif" font-style="italic" font-weight="800" font-size="30" fill="#0c0d0d" stroke="#eef5fb" stroke-width="6" paint-order="stroke">Bratislava</text>
      </svg>
    </div>

    <form class="order-card rv d2" data-order method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
      <?php ck_order_fields(); ?>
      <h3>Rýchly zásah do 60 minút</h3>
      <a class="phone" href="<?php echo esc_attr( ck_tel() ); ?>"><?php echo esc_html( ck_phone() ); ?></a>
      <label for="o-name">Meno<input id="o-name" name="name" autocomplete="name" placeholder="Ján Novák" required></label>
      <label for="o-phone">Telefón<input id="o-phone" name="phone" type="tel" autocomplete="tel" placeholder="09xx xxx xxx" required></label>
      <label for="o-type">Čo treba vyčistiť<select id="o-type" name="type">
        <option>Nástenná klimatizácia</option>
        <option>Viac jednotiek</option>
        <option>Kazetová / kanálová</option>
        <option>Radiátory</option>
      </select></label>
      <button class="btn white" type="submit"><span>Objednať teraz</span></button>
      <?php ck_order_notice(); ?>
    </form>
  </div>
</section>

<?php get_footer(); ?>
