<?php
/**
 * Záložná šablóna (blog, archívy, vyhľadávanie).
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<section class="page-hero">
  <div class="wrap">
    <h1><?php echo is_home() ? esc_html( get_the_title( get_option( 'page_for_posts' ) ) ?: 'Blog' ) : wp_kses_post( get_the_archive_title() ); ?></h1>
  </div>
</section>
<section class="page-simple">
  <div class="wrap prose">
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
      <article>
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <?php the_excerpt(); ?>
      </article>
    <?php endwhile; the_posts_pagination(); else : ?>
      <p>Nič sme nenašli.</p>
    <?php endif; ?>
  </div>
</section>
<?php
get_footer();
